from flask.ext.script import Manager, Shell




